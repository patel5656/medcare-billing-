// src/pages/clinical/AssessmentsAndFormsPage.jsx
import React, { useState } from 'react';
import { UnifiedPacketViewer } from '../../components/packets/UnifiedPacketViewer';
import { AnikTherapyAssessmentForm } from '../../components/packets/anik/AnikTherapyAssessmentForm';
import { DavProgressNote } from '../../components/packets/davs/DavProgressNote';
import { Clock } from 'lucide-react';

export const AssessmentsAndFormsPage = () => {
  const [activeTab, setActiveTab] = useState('ANIK');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Assessments & Clinical Procedure Forms</h1>
        <p className="text-xs text-slate-500">Provider-specific specialized evaluation and therapy session documentation forms</p>
      </div>

      {/* Modality Tabs */}
      <div className="flex items-center gap-2 bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
        <button
          onClick={() => setActiveTab('JOSMIC')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'JOSMIC' ? 'bg-teal-600 text-white shadow-sm' : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          Pain Management (JOSMIC Pain Report)
        </button>
        <button
          onClick={() => setActiveTab('ANIK')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'ANIK' ? 'bg-violet-600 text-white shadow-sm' : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          Laser Therapy (ANIK Assessment & Procedure)
        </button>
        <button
          onClick={() => setActiveTab('DAVS')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'DAVS' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          Shockwave Therapy (DAV'S ESWT Form)
        </button>
        <button
          onClick={() => setActiveTab('TPI')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'TPI' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Trigger Point Injection (Pending)
        </button>
        <button
          onClick={() => setActiveTab('TECAR')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'TECAR' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          TECAR Therapy (Pending)
        </button>
        <button
          onClick={() => setActiveTab('COUNSELOR')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'COUNSELOR' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Counseling (4 Pages)
        </button>
      </div>

      {/* Content Rendering */}
      {activeTab === 'JOSMIC' && (
        <UnifiedPacketViewer providerId="prov-josmic" />
      )}

      {activeTab === 'ANIK' && (
        <UnifiedPacketViewer providerId="prov-anik" />
      )}

      {activeTab === 'DAVS' && (
        <UnifiedPacketViewer providerId="prov-davs" />
      )}

      {activeTab === 'COUNSELOR' && (
        <UnifiedPacketViewer providerId="prov-counselor" />
      )}

      {activeTab === 'TPI' && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-8 text-center space-y-3">
          <Clock className="w-10 h-10 text-amber-600 mx-auto" />
          <h3 className="text-base font-bold text-amber-900">Trigger Point Injection — Configuration Pending</h3>
          <p className="text-xs text-amber-800 max-w-lg mx-auto leading-relaxed">
            Clinical Form Pending. Trigger Point Injection form templates and clinical session workflows will be available once provider-service configuration is completed.
          </p>
        </div>
      )}

      {activeTab === 'TECAR' && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-8 text-center space-y-3">
          <Clock className="w-10 h-10 text-rose-600 mx-auto" />
          <h3 className="text-base font-bold text-rose-900">TECAR Therapy — Configuration Pending</h3>
          <p className="text-xs text-rose-800 max-w-lg mx-auto leading-relaxed">
            Clinical Form Pending. Radiofrequency Energy Transfer (TECAR Therapy) procedure forms will be enabled upon provider assignment.
          </p>
        </div>
      )}
    </div>
  );
};
