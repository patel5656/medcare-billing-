// src/constants/packetManifests.js

/**
 * Provider-Specific Page Manifests
 * ANIK: 16 Pages
 * DAV'S: 14 Pages
 * JOSMIC: 7 Pages
 */

export const PACKET_MANIFESTS = {
  'prov-anik': {
    providerId: 'prov-anik',
    providerName: 'ANIK Laser Therapy',
    totalPages: 16,
    pages: [
      { pageNumber: 1, id: 'anik-cover', type: 'COVER', title: 'Patient & Case Cover Page', componentKey: 'AnikCoverPage' },
      { pageNumber: 2, id: 'anik-bill-1', type: 'BILLING', title: 'Provider Billing Statement (Page 1)', componentKey: 'PrintableBillingStatement', pageIndex: 0 },
      { pageNumber: 3, id: 'anik-bill-2', type: 'BILLING', title: 'Provider Billing Statement (Page 2 - Ledger)', componentKey: 'PrintableBillingStatement', pageIndex: 1 },
      { pageNumber: 4, id: 'anik-cms-1', type: 'CMS-1500', title: 'CMS-1500 Claim (01/22/2026)', componentKey: 'CmsRedGridForm', claimIndex: 0 },
      { pageNumber: 5, id: 'anik-cms-2', type: 'CMS-1500', title: 'CMS-1500 Claim (01/24/2026)', componentKey: 'CmsRedGridForm', claimIndex: 1 },
      { pageNumber: 6, id: 'anik-cms-3', type: 'CMS-1500', title: 'CMS-1500 Claim (01/26/2026)', componentKey: 'CmsRedGridForm', claimIndex: 2 },
      { pageNumber: 7, id: 'anik-assess', type: 'ASSESSMENT', title: 'Therapy Assessment Chart', componentKey: 'AnikTherapyAssessmentForm' },
      { pageNumber: 8, id: 'anik-proc-1', type: 'PROCEDURE', title: 'Laser Procedure Form (01/22/2026)', componentKey: 'AnikLaserProcedureForm', dos: '01/22/2026' },
      { pageNumber: 9, id: 'anik-proc-2', type: 'PROCEDURE', title: 'Laser Procedure Form (01/24/2026)', componentKey: 'AnikLaserProcedureForm', dos: '01/24/2026' },
      { pageNumber: 10, id: 'anik-proc-3', type: 'PROCEDURE', title: 'Laser Procedure Form (01/26/2026)', componentKey: 'AnikLaserProcedureForm', dos: '01/26/2026' },
      { pageNumber: 11, id: 'anik-narr-1', type: 'NARRATIVE', title: 'Initial Narrative Report (Page 1)', componentKey: 'AnikNarrativeReport', reportPage: 1 },
      { pageNumber: 12, id: 'anik-narr-2', type: 'NARRATIVE', title: 'Initial Narrative Report (Page 2)', componentKey: 'AnikNarrativeReport', reportPage: 2 },
      { pageNumber: 13, id: 'anik-narr-3', type: 'NARRATIVE', title: 'Initial Narrative Report (Page 3)', componentKey: 'AnikNarrativeReport', reportPage: 3 },
      { pageNumber: 14, id: 'anik-final-1', type: 'NARRATIVE', title: 'Final Medical / Discharge Report (Page 1)', componentKey: 'AnikFinalReport', reportPage: 1 },
      { pageNumber: 15, id: 'anik-final-2', type: 'NARRATIVE', title: 'Final Medical / Discharge Report (Page 2)', componentKey: 'AnikFinalReport', reportPage: 2 },
      { pageNumber: 16, id: 'anik-final-3', type: 'NARRATIVE', title: 'Final Medical / Discharge Report (Page 3)', componentKey: 'AnikFinalReport', reportPage: 3 },
    ]
  },

  'prov-davs': {
    providerId: 'prov-davs',
    providerName: "DAV'S Anatomy",
    totalPages: 14,
    pages: [
      { pageNumber: 1, id: 'davs-cover', type: 'COVER', title: 'Patient & Case Cover Page', componentKey: 'DavCoverPage' },
      { pageNumber: 2, id: 'davs-bill-1', type: 'BILLING', title: 'Provider Billing Statement (Page 1)', componentKey: 'PrintableBillingStatement', pageIndex: 0 },
      { pageNumber: 3, id: 'davs-bill-2', type: 'BILLING', title: 'Provider Billing Statement (Page 2 - Ledger)', componentKey: 'PrintableBillingStatement', pageIndex: 1 },
      { pageNumber: 4, id: 'davs-cms-1', type: 'CMS-1500', title: 'CMS-1500 Claim Form', componentKey: 'CmsRedGridForm', claimIndex: 0 },
      { pageNumber: 5, id: 'davs-cms-2', type: 'CMS-1500', title: 'CMS-1500 Claim Form', componentKey: 'CmsRedGridForm', claimIndex: 1 },
      { pageNumber: 6, id: 'davs-cms-3', type: 'CMS-1500', title: 'CMS-1500 Claim Form', componentKey: 'CmsRedGridForm', claimIndex: 2 },
      { pageNumber: 7, id: 'davs-prog-1', type: 'ASSESSMENT', title: 'Clinical Progress Note (Page 1)', componentKey: 'DavProgressNote', notePage: 1 },
      { pageNumber: 8, id: 'davs-prog-2', type: 'ASSESSMENT', title: 'Clinical Progress Note (Page 2)', componentKey: 'DavProgressNote', notePage: 2 },
      { pageNumber: 9, id: 'davs-proc-1', type: 'PROCEDURE', title: 'ESWT Shockwave Form (01/22/2026)', componentKey: 'DavEswtProcedureForm', pageIndex: 0, formPage: 1, dos: '01/22/2026' },
      { pageNumber: 10, id: 'davs-proc-2', type: 'PROCEDURE', title: 'ESWT Shockwave Form (01/24/2026)', componentKey: 'DavEswtProcedureForm', pageIndex: 1, formPage: 2, dos: '01/24/2026' },
      { pageNumber: 11, id: 'davs-proc-3', type: 'PROCEDURE', title: 'ESWT Shockwave Form (01/26/2026)', componentKey: 'DavEswtProcedureForm', pageIndex: 2, formPage: 3, dos: '01/26/2026' },
      { pageNumber: 12, id: 'davs-final-1', type: 'NARRATIVE', title: 'Shockwave Narrative Report (Page 1)', componentKey: 'DavFinalNarrative', reportPage: 1 },
      { pageNumber: 13, id: 'davs-final-2', type: 'NARRATIVE', title: 'Shockwave Narrative Report (Page 2)', componentKey: 'DavFinalNarrative', reportPage: 2 },
      { pageNumber: 14, id: 'davs-final-3', type: 'NARRATIVE', title: 'Shockwave Narrative Report (Page 3)', componentKey: 'DavFinalNarrative', reportPage: 3 },
    ]
  },

  'prov-josmic': {
    providerId: 'prov-josmic',
    providerName: 'JOSMIC Wellness Center',
    totalPages: 7,
    pages: [
      { pageNumber: 1, id: 'josmic-cover', type: 'COVER', title: 'Patient & Case Cover Page', componentKey: 'JosmicCoverPage' },
      { pageNumber: 2, id: 'josmic-bill-1', type: 'BILLING', title: 'Provider Billing Statement', componentKey: 'PrintableBillingStatement', pageIndex: 0 },
      { pageNumber: 3, id: 'josmic-cms-1', type: 'CMS-1500', title: 'CMS-1500 Claim (12/30/2025)', componentKey: 'CmsRedGridForm', claimIndex: 0 },
      { pageNumber: 4, id: 'josmic-pain-1', type: 'NARRATIVE', title: 'Pain Management Report (Page 1)', componentKey: 'JosmicPainManagementReport', reportPage: 1 },
      { pageNumber: 5, id: 'josmic-pain-2', type: 'NARRATIVE', title: 'Pain Management Report (Page 2)', componentKey: 'JosmicPainManagementReport', reportPage: 2 },
      { pageNumber: 6, id: 'josmic-pain-3', type: 'NARRATIVE', title: 'Pain Management Report (Page 3)', componentKey: 'JosmicPainManagementReport', reportPage: 3 },
      { pageNumber: 7, id: 'josmic-pain-4', type: 'NARRATIVE', title: 'Pain Management Report (Page 4)', componentKey: 'JosmicPainManagementReport', reportPage: 4 },
    ]
  },

  'prov-counselor': {
    providerId: 'prov-counselor',
    providerName: 'Counselor Practice (Hope Behavioral Health)',
    totalPages: 4,
    pages: [
      { pageNumber: 1, id: 'counselor-cover', type: 'COVER', title: 'Patient & Case Cover Page', componentKey: 'CounselorCoverPage' },
      { pageNumber: 2, id: 'counselor-assess', type: 'ASSESSMENT', title: 'Behavioral Health & Psychotherapy Assessment', componentKey: 'CounselorAssessmentForm' },
      { pageNumber: 3, id: 'counselor-bill-1', type: 'BILLING', title: 'Provider Billing Statement (#1024-C)', componentKey: 'PrintableBillingStatement', pageIndex: 0 },
      { pageNumber: 4, id: 'counselor-cms-1', type: 'CMS-1500', title: 'CMS-1500 Claim (01/05/2026)', componentKey: 'CmsRedGridForm', claimIndex: 0 },
    ]
  },

  'prov-tpi': {
    providerId: 'prov-tpi',
    providerName: 'Trigger Point Injection Clinic',
    totalPages: 5,
    pages: [
      { pageNumber: 1, id: 'tpi-cover', type: 'COVER', title: 'Patient & Case Cover Page', componentKey: 'TpiCoverPage' },
      { pageNumber: 2, id: 'tpi-bill-1', type: 'BILLING', title: 'Provider Billing Statement', componentKey: 'PrintableBillingStatement', pageIndex: 0 },
      { pageNumber: 3, id: 'tpi-cms-1', type: 'CMS-1500', title: 'CMS-1500 Claim', componentKey: 'CmsRedGridForm', claimIndex: 0 },
      { pageNumber: 4, id: 'tpi-assess', type: 'ASSESSMENT', title: 'Trigger Point Assessment', componentKey: 'TpiAssessmentForm' },
      { pageNumber: 5, id: 'tpi-proc-1', type: 'PROCEDURE', title: 'Trigger Point Procedure', componentKey: 'TpiProcedureForm', dos: '01/15/2026' }
    ]
  },

  'prov-tecar': {
    providerId: 'prov-tecar',
    providerName: 'TECAR Therapy Clinic',
    totalPages: 5,
    pages: [
      { pageNumber: 1, id: 'tecar-cover', type: 'COVER', title: 'Patient & Case Cover Page', componentKey: 'TecarCoverPage' },
      { pageNumber: 2, id: 'tecar-bill-1', type: 'BILLING', title: 'Provider Billing Statement', componentKey: 'PrintableBillingStatement', pageIndex: 0 },
      { pageNumber: 3, id: 'tecar-cms-1', type: 'CMS-1500', title: 'CMS-1500 Claim', componentKey: 'CmsRedGridForm', claimIndex: 0 },
      { pageNumber: 4, id: 'tecar-assess', type: 'ASSESSMENT', title: 'TECAR Therapy Assessment', componentKey: 'TecarAssessmentForm' },
      { pageNumber: 5, id: 'tecar-proc-1', type: 'PROCEDURE', title: 'TECAR Procedure Log', componentKey: 'TecarProcedureForm', dos: '01/20/2026' }
    ]
  },

  'prov-general': {
    providerId: 'prov-general',
    providerName: 'General Final Treatment',
    totalPages: 1,
    pages: [
      { pageNumber: 1, id: 'general-final', type: 'NARRATIVE', title: 'Final Treatment Report', componentKey: 'PatientFinalTreatmentReport' }
    ]
  }
};

